'use strict';

// eslint-disable-next-line no-unused-vars
class Safe {
  #key = '';

  #encoder = new TextEncoder();
  #decoder = new TextDecoder();

  #buffer(string) {
    const bytes = new Uint8Array(string.length);
    [...string].forEach((c, i) => bytes[i] = c.charCodeAt(0));
    return bytes;
  }

  async open(password) {
    this.#key = await crypto.subtle.digest({
      name: 'SHA-256'
    }, this.#encoder.encode(password)).then(result => crypto.subtle.importKey('raw', result, {
      name: 'AES-CBC'
    }, true, ['encrypt', 'decrypt']));
  }
  export() {
    return crypto.subtle.exportKey('raw', this.#key).then(ab => {
      return btoa(String.fromCharCode(...new Uint8Array(ab)));
    });
  }
  import(string) {/* Uint8Array */
    const decodedKeyData = new Uint8Array(Array.from(atob(string), c => c.charCodeAt(0)));

    if (decodedKeyData.byteLength !== 16 && decodedKeyData.byteLength !== 32) {
      return Promise.reject(Error('INVALID_EXPORTED_KEY_LENGTH'));
    }

    return crypto.subtle.importKey('raw', decodedKeyData, {
      name: 'AES-CBC'
    }, true, ['encrypt', 'decrypt']).then(key => {
      this.#key = key;
    });
  }
  async encrypt(string) {
    const iv = crypto.getRandomValues(new Uint8Array(16));

    const result = await crypto.subtle.encrypt({
      name: 'AES-CBC',
      iv
    }, this.#key, this.#encoder.encode(string));

    // Preserve the existing IV + ciphertext format without DOM-only FileReader.
    const bytes = new Uint8Array(iv.length + result.byteLength);
    bytes.set(iv);
    bytes.set(new Uint8Array(result), iv.length);
    let binary = '';
    for (const byte of bytes) binary += String.fromCharCode(byte);
    return btoa(binary);
  }
  async decrypt(string) {
    // compatibility fix
    string = string.replace('data:application/octet-binary;base64,', '');

    const bytes = this.#buffer(atob(string));
    const iv = bytes.subarray(0, 16);

    const result = await crypto.subtle.decrypt({
      name: 'AES-CBC',
      iv
    }, this.#key, bytes.subarray(16));
    return this.#decoder.decode(result);
  }
}
