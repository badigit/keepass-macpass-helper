// Polyfills for engine scripts that reference window
self.window = self;
self.KWPASS = class {
  async prepare() {}
  async search() { return { Entries: [] }; }
  async set() { throw Error('Not_Supported'); }
};
self.kdbxweb = {};

importScripts(
  '/tools/tld.js',
  '/tools/url-lookup.js',
  '/tools/hints-target.js',
  '/tools/scriptable-url.js',
  '/connect/SecureSyncedDB.js',
  '/connect/api.js',
  '/connect/keepass/keepass.js',
  '/connect/keepassxc/nacl-fast.min.js',
  '/connect/keepassxc/keepassxc.js',
  '/connect/totp.js',
  '/connect/otp-resolve.js',
  // Single source of truth for field-detection regexes across content script,
  // service worker, and node tests. Exposes self.__kpHints.
  '/data/hints/heuristics.js',
  // Password generators (charset + diceware). Exposes self.__kpPasswordGen.
  '/tools/diceware-words.js',
  '/tools/password-gen.js',
  '/tools/password-prefs.js',
  '/tools/safe.js'
);

const {searchWithUrlFallback, isLookupCandidate, linkOrigin} = self.__kpUrlLookup;
const {senderScriptTarget} = self.__kpHintsTarget;
const {isScriptableUrl} = self.__kpScriptableUrl;

const current = () => chrome.tabs.query({
  lastFocusedWindow: true,
  active: true,
  windowType: 'normal'
}).then(tbs => {
  if (tbs.length === 0) {
    return chrome.tabs.query({
      active: true,
      windowType: 'normal'
    }).then(tbs => tbs[0]);
  }
  return tbs[0];
});

const notify = async (tab, e, badge = 'E', color = '#d93025') => {
  tab = tab || await current();

  chrome.action.setBadgeText({
    tabId: tab.id,
    text: badge
  });
  chrome.action.setBadgeBackgroundColor({
    tabId: tab.id,
    color
  });
  chrome.action.setTitle({
    tabId: tab.id,
    title: e.message || e
  });

  clearTimeout(notify.id);
  notify.id = setTimeout(() => chrome.action.setBadgeText({
    tabId: tab.id,
    text: ''
  }), 3000);
};

// eslint-disable-next-line no-unused-vars
const storage = { // used by "associate"
  get(name) {
    try {
      return localStorage.getItem(name);
    }
    catch (e) {
      return undefined;
    }
  },
  set(name, value) {
    try {
      localStorage.setItem(name, value);
    }
    catch (e) {}
  },
  remote: o => new Promise(resolve => chrome.storage.local.get(o, resolve))
};

// Hints engine — lazy init, search without passwords
const hints = {
  ready: false,
  preparing: null,
  reset() {
    this.ready = false;
    this.preparing = null;
  },
  async ensureReady(force = false) {
    if (force) {
      this.reset();
    }
    if (!this.ready) {
      if (!this.preparing) {
        this.preparing = (async () => {
          const prefs = await storage.remote({engine: 'keepass'});
          await engine.prepare(prefs.engine);
          if (prefs.engine === 'keepass') {
            await engine.core.test(false);
          }
          else if (prefs.engine === 'keepassxc') {
            await engine.core['test-associate']();
          }
          this.ready = true;
        })().catch(e => {
          console.warn('hints engine:', e);
        }).finally(() => {
          this.preparing = null;
        });
      }
      await this.preparing;
    }
  },
  async searchExact(url, {force = false} = {}) {
    try {
      await this.ensureReady(force);
      if (!this.ready) {
        return {Entries: []};
      }
      return await engine.search({url});
    }
    catch (e) {
      this.reset();
      if (!force) {
        await this.ensureReady(true);
        if (this.ready) {
          return engine.search({url});
        }
      }
      throw e;
    }
  },
  async search(url, {force = false} = {}) {
    let first = true;
    return searchWithUrlFallback(candidate => {
      const candidateForce = force && first;
      first = false;
      return this.searchExact(candidate, {force: candidateForce});
    }, url);
  },
  async manualSearch(query) {
    await this.ensureReady();
    if (!this.ready || engine.type !== 'keepass' || !engine.core.customSearch) {
      throw Error('Manual database search requires KeePassHTTP 2.3.1 or newer');
    }
    return engine.core.customSearch(query);
  },
  async getByUuid(uuid) {
    await this.ensureReady();
    if (!this.ready || engine.type !== 'keepass' || !engine.core.getByUuid) {
      throw Error('UUID lookup requires KeePassHTTP 2.3.1 or newer');
    }
    return engine.core.getByUuid(uuid);
  },
  async linkCurrentSite(uuid, pageUrl) {
    await this.ensureReady();
    if (!this.ready || engine.type !== 'keepass' || !engine.core.set) {
      return {ok: false, code: 'unsupported'};
    }
    const origin = linkOrigin(pageUrl);
    if (!origin) {
      return {ok: false, code: 'invalid-url'};
    }
    const result = await engine.core.set({
      uuid,
      url: origin,
      onlyIfUrlEmpty: true
    });
    if (!result?.Success) {
      return {ok: false, code: result?.Error || 'update-failed'};
    }
    return {ok: true, origin};
  }
};

const entryOTP = entry => OTPResolve.get(entry);

const copy = async (content, tab, frameId) => {
  // Firefox
  try {
    await navigator.clipboard.writeText(content);
    notify(undefined, 'Done', '✓', 'green');
  }
  catch (e) {
    try {
      await chrome.scripting.executeScript({
        target: {
          tabId: tab.id,
          ...(Number.isInteger(frameId) ? {frameIds: [frameId]} : {})
        },
        func: password => {
          navigator.clipboard.writeText(password).then(() => chrome.runtime.sendMessage({
            cmd: 'notify',
            message: 'Done',
            badge: '✓',
            color: 'green'
          })).catch(() => chrome.runtime.sendMessage({
            cmd: 'copy-interface',
            password
          }));
        },
        args: [content]
      });
    }
    catch (e) {
      copy.interface(content);
    }
  }
};
copy.interface = async content => {
  if (typeof content !== 'string') throw Error('Clipboard content must be text');
  const id = crypto.randomUUID();
  const key = 'kp-copy:' + id;
  await chrome.storage.session.set({[key]: {content, expires: Date.now() + 120000}});
  try {
    const win = await chrome.windows.getCurrent();
    await chrome.windows.create({
      url: '/data/copy/index.html?id=' + id,
      width: 400,
      height: 300,
      left: win.left + Math.round((win.width - 400) / 2),
      top: win.top + Math.round((win.height - 300) / 2),
      type: 'popup'
    });
  }
  catch (e) {
    await chrome.storage.session.remove(key);
    throw e;
  }
};
chrome.storage.session.get(null).then(entries => {
  const expired = Object.keys(entries).filter(key => key.startsWith('kp-copy:') && entries[key].expires < Date.now());
  return chrome.storage.session.remove(expired);
}).catch(e => console.warn('Clipboard cleanup:', e));

// Call from the click/message handler before any await preserves user activation.
const saveRequests = new Map();
let saveRevision = Date.now();
const openSaveForm = async (tab, prepare) => {
  const requestId = crypto.randomUUID();
  const revision = saveRevision = Math.max(saveRevision + 1, Date.now());
  saveRequests.set(tab.id, requestId);
  const key = 'kp-save-form:' + tab.id;
  const path = '/data/save/index.html?tab=' + tab.id;
  try {
    const seeded = chrome.storage.session.set({[key]: {requestId, revision, pending: true, url: tab.url}});
    const configured = chrome.sidePanel.setOptions({tabId: tab.id, path, enabled: true});
    const opened = chrome.sidePanel.open({tabId: tab.id});
    await Promise.all([seeded, configured, opened]);
    const payload = await prepare();
    if (saveRequests.get(tab.id) === requestId) {
      await chrome.storage.session.set({[key]: {...payload, requestId, revision, pending: false}});
    }
  }
  catch (e) {
    if (saveRequests.get(tab.id) === requestId) {
      await chrome.storage.session.set({[key]: {requestId, revision, error: e.message, url: tab.url}});
    }
    throw e;
  }
};

// Generates a password with the same preferences the save form stores, so the
// value typed into the page matches what the form would have produced.
const generatePassword = async () => {
  const prefs = await self.__kpPasswordPrefs.load(chrome.storage.local);
  return self.__kpPasswordGen.generate(prefs);
};

// messaging
const clipboardReads = new Set();
chrome.runtime.onMessage.addListener((request, sender, response) => {
  if (request.cmd === 'close-me') {
    chrome.scripting.executeScript({
      target: {
        tabId: sender.tab.id
      },
      func: () => {
        for (const e of document.querySelectorAll('dialog.kphelper')) {
          e.remove();
        }

        window.focus();
        try {
          window.aElement.focus();
        }
        catch (e) {
          document.activeElement.focus();
        }
      }
    });
  }
  else if (request.cmd === 'notify') {
    notify(undefined, request.message, request.badge, request.color);
  }
  else if (request.cmd === 'copy-interface') {
    copy.interface(request.password).then(() => response({ok: true})).catch(e => response({ok: false, error: e.message}));
    return true;
  }
  else if (request.cmd === 'copy-payload') {
    (async () => {
      const source = new URL(sender.url || 'about:blank');
      const expected = new URL(chrome.runtime.getURL('/data/copy/index.html'));
      if (source.protocol !== expected.protocol || source.host !== expected.host || source.pathname !== expected.pathname ||
          source.searchParams.get('id') !== request.id || !/^[\da-f-]{36}$/i.test(request.id || '')) {
        throw Error('Invalid clipboard request');
      }
      const key = 'kp-copy:' + request.id;
      if (clipboardReads.has(key)) throw Error('Clipboard request already being consumed');
      clipboardReads.add(key);
      try {
        const payload = (await chrome.storage.session.get(key))[key];
        await chrome.storage.session.remove(key);
        if (!payload || payload.expires < Date.now()) throw Error('Clipboard request expired');
        return {ok: true, content: payload.content};
      }
      finally {
        clipboardReads.delete(key);
      }
    })().then(response).catch(e => response({ok: false, error: e.message}));
    return true;
  }
  else if (request.cmd === 'native') {
    chrome.runtime.sendNativeMessage(request.id, request.request, response);
    return true;
  }
  else if (request.cmd === 'session-storage-get') {
    chrome.storage.session.get(request.prefs, response);
    return true;
  }
  else if (request.cmd === 'hints-search') {
    hints.search(request.url, {
      force: request.force === true
    }).then(r => {
      const entries = (r.Entries || []).map((e, i) => ({
        Login: e.Login || '',
        Name: e.Name || '',
        group: e.group || '',
        originalIndex: e.__kpLookup?.index ?? i,
        lookupUrl: e.__kpLookup?.url || request.url
      }));
      response({entries, ok: true});
    }).catch(e => {
      console.warn('hints-search:', e);
      response({
        entries: [],
        ok: false,
        error: e?.message || String(e)
      });
    });
    return true;
  }
  else if (request.cmd === 'hints-manual-search') {
    const query = String(request.query || '').trim().slice(0, 200);
    if (query.length < 2) {
      response({entries: [], ok: true});
      return false;
    }
    hints.manualSearch(query).then(r => {
      const entries = (r.Entries || []).map(e => ({
        Login: e.Login || '',
        Name: e.Name || '',
        group: e.Group?.Name || '',
        uuid: e.Uuid || '',
        hasUrl: typeof e.HasUrl === 'boolean' ? e.HasUrl : null,
        canLink: e.HasUrl === false && e.SupportsConditionalUrlUpdate === true
      })).filter(e => e.uuid);
      response({entries, ok: true});
    }).catch(e => {
      console.warn('hints-manual-search:', e);
      response({
        entries: [],
        ok: false,
        error: e?.message || String(e)
      });
    });
    return true;
  }
  else if (request.cmd === 'hints-link-current-site') {
    const uuid = String(request.uuid || '');
    if (!/^[0-9a-f]{32}$/i.test(uuid)) {
      response({ok: false, code: 'invalid-entry'});
      return false;
    }
    // Use the frame that rendered the confirmation. For cross-origin login
    // iframes, sender.tab.url would save a different origin than the user saw.
    hints.linkCurrentSite(uuid, sender.url || sender.tab?.url || '').then(response).catch(e => {
      console.warn('hints-link-current-site:', e);
      response({ok: false, code: 'update-failed'});
    });
    return true;
  }
  else if (request.cmd === 'hints-fill') {
    (async () => {
      try {
        const scriptTarget = senderScriptTarget(sender);
        if (!scriptTarget) return;
        let entry;
        if (request.uuid) {
          const r = await hints.getByUuid(request.uuid);
          entry = (r.Entries || [])[0];
        }
        else {
          const lookupUrl = isLookupCandidate(request.url, request.lookupUrl) ?
            request.lookupUrl : request.url;
          const r = await hints.searchExact(lookupUrl);
          entry = (r.Entries || [])[request.index];
        }
        if (!entry) {
          return;
        }
        if (request.target === 'otp') {
          const otp = await entryOTP(entry).catch(() => '');
          if (!otp) {
            return;
          }
          // Inject helper.js (setInputValue) and heuristics.js (isOTPField) into
          // the page. The heuristics file is also injected as a content script,
          // but content scripts live in the isolated world; we need __kpHints in
          // the main world so the executeScript func below can reach it.
          await chrome.scripting.executeScript({
            target: scriptTarget,
            files: ['/data/helper.js', '/data/hints/heuristics.js', '/tools/hints-field.js']
          });
          await chrome.scripting.executeScript({
            target: scriptTarget,
            func: otp => {
              const {isOTPField} = self.__kpHints;
              const active = self.__kpHintsField.takeHintField(self, document);
              const candidates = [...document.querySelectorAll('input')].filter(e => e.offsetParent);
              const field = isOTPField(active) ? active : (candidates.find(isOTPField) || active);
              if (!field || field.tagName !== 'INPUT') return;
              self.setInputValue(field, otp);
            },
            args: [otp]
          });
          return;
        }
        const username = entry.Login || '';
        const password = entry.Password || '';

        // Inject helper.js (setInputValue/detectForm) and heuristics.js
        // (USER_RE) into the page's isolated world.
        await chrome.scripting.executeScript({
          target: scriptTarget,
          files: ['/data/helper.js', '/data/hints/heuristics.js', '/tools/hints-field.js']
        });

        // Fill credentials via executeScript — password never touches content script
        await chrome.scripting.executeScript({
          target: scriptTarget,
          func: (username, password) => {
            const {USER_RE} = self.__kpHints;
            const active = self.__kpHintsField.takeHintField(self, document);
            // Find the form context
            const form = self.detectForm
              ? self.detectForm(active)
              : active.closest('form') || document;

            // Fill password
            const pwFields = [...form.querySelectorAll('input[type=password]')]
              .filter(e => e.offsetParent);
            for (const e of pwFields) {
              self.setInputValue(e, password);
            }

            // Fill username last: some SPAs overwrite username state when password changes.
            const userFields = [...form.querySelectorAll('input')].filter(e => {
              if (!e.offsetParent) {
                return false;
              }
              const t = (e.type || '').toLowerCase();
              return ['text', 'email', 'tel', 'search', 'url', 'number', ''].includes(t);
            });

            if (username && userFields.length) {
              const target = userFields.find(e => {
                const hint = e.name + ' ' + e.id + ' ' + (e.getAttribute('autocomplete') || '');
                return USER_RE.test(hint);
              }) || userFields[0];
              self.setInputValue(target, username);
            }
          },
          args: [username, password]
        });
      }
      catch (e) {
        console.warn('hints-fill:', e);
      }
    })();
  }
  else if (request.cmd === 'hints-entry-action') {
    (async () => {
      const uuid = String(request.uuid || '');
      const field = request.field === 'password' ? 'password' :
        request.field === 'login' ? 'login' : '';
      const action = request.action === 'copy' ? 'copy' :
        request.action === 'fill' ? 'fill' : '';
      const scriptTarget = senderScriptTarget(sender);
      if (!/^[0-9a-f]{32}$/i.test(uuid) || !field || !action || !scriptTarget) {
        return {ok: false, code: 'invalid-request'};
      }

      const result = await hints.getByUuid(uuid);
      const entry = (result.Entries || [])[0];
      if (!entry) return {ok: false, code: 'entry-not-found'};
      const value = field === 'password' ? (entry.Password || '') : (entry.Login || '');
      if (!value) return {ok: false, code: 'empty-value'};

      if (action === 'copy') {
        await copy(value, sender.tab, sender.frameId);
        return {ok: true};
      }

      await chrome.scripting.executeScript({
        target: scriptTarget,
        files: ['/data/helper.js', '/data/hints/heuristics.js', '/tools/hints-field.js']
      });
      const injection = await chrome.scripting.executeScript({
        target: scriptTarget,
        func: (value, field) => {
          const active = self.__kpHintsField.takeHintField(self, document);
          const visible = element => Boolean(element?.offsetParent);
          let target;
          if (field === 'password') {
            target = active?.matches?.('input[type=password]') && visible(active) ? active :
              [...document.querySelectorAll('input[type=password]')].find(visible);
          }
          else {
            const {USER_RE} = self.__kpHints;
            const isLoginCandidate = element => {
              if (!visible(element)) return false;
              const type = (element.type || '').toLowerCase();
              return ['text', 'email', 'tel', 'search', 'url', 'number', ''].includes(type);
            };
            const candidates = [...document.querySelectorAll('input')].filter(isLoginCandidate);
            target = isLoginCandidate(active) ? active :
              candidates.find(element => {
                const hint = `${element.name} ${element.id} ${element.getAttribute('autocomplete') || ''}`;
                return USER_RE.test(hint);
              }) || candidates[0];
          }
          if (!target) return false;
          self.setInputValue(target, value);
          return target.value === value;
        },
        args: [value, field]
      });
      return {ok: injection.some(item => item.result === true)};
    })().then(response).catch(e => {
      console.warn('hints-entry-action:', e);
      response({ok: false, code: 'action-failed'});
    });
    return true;
  }
  else if (request.cmd === 'hints-save-form') {
    (async () => {
      const tab = sender.tab;
      if (!tab || !tab.id) {
        return {ok: false};
      }
      await openSaveForm(tab, async () => {
        const frameIds = [sender.frameId ?? 0];
        let password = request.password || '';
        // Type the generated registration password into its original page field.
        if (!password && request.generate) {
          password = await generatePassword();
          await chrome.scripting.executeScript({
            target: {tabId: tab.id, frameIds},
            files: ['/data/helper.js', '/tools/hints-field.js']
          });
          await chrome.scripting.executeScript({
            target: {tabId: tab.id, frameIds},
            func: value => {
              const field = self.__kpHintsField.takeHintField(self, document);
              if (field && field.tagName === 'INPUT' && field.type === 'password') {
                self.setInputValue(field, value);
              }
            },
            args: [password]
          });
        }
        return {
          url: request.url || tab.url,
          favicon: tab.favIconUrl,
          pairs: [{
            usernames: request.login ? [request.login] : [],
            passwords: password ? [password] : []
          }]
        };
      });
      return {ok: true};
    })().then(response).catch(e => {
      console.warn('hints-save-form:', e);
      response({ok: false, error: e.message});
    });
    return true;
  }
  else if (request.cmd === 'hints-report-unwanted') {
    (async () => {
      try {
        const {hintsUnwantedReports = []} = await chrome.storage.local.get('hintsUnwantedReports');
        hintsUnwantedReports.push(request.fieldMeta);
        // Keep last 500 reports max
        if (hintsUnwantedReports.length > 500) {
          hintsUnwantedReports.splice(0, hintsUnwantedReports.length - 500);
        }
        await chrome.storage.local.set({hintsUnwantedReports});
      }
      catch (e) {
        console.warn('hints-report-unwanted:', e);
      }
    })();
  }
  else if (request.cmd === 'hints-report-missed') {
    (async () => {
      try {
        const {hintsMissedReports = []} = await chrome.storage.local.get('hintsMissedReports');
        hintsMissedReports.push(request.fieldMeta);
        if (hintsMissedReports.length > 500) {
          hintsMissedReports.splice(0, hintsMissedReports.length - 500);
        }
        await chrome.storage.local.set({hintsMissedReports});
      }
      catch (e) {
        console.warn('hints-report-missed:', e);
      }
    })();
  }
});

// Context Menu
{
  const once = () => {
    if (once.done) {
      return;
    }
    once.done = true;
    chrome.contextMenus.remove('auto-login', () => chrome.runtime.lastError);

    chrome.contextMenus.create({
      id: 'generate-password',
      title: 'Generate a Random Password',
      contexts: ['action']
    }, () => chrome.runtime.lastError);
    chrome.contextMenus.create({
      id: 'save-form',
      title: 'Save a new Login Form in KeePass',
      contexts: ['action']
    }, () => chrome.runtime.lastError);
    chrome.contextMenus.create({
      id: 'hints-open',
      title: 'Show KeePass Suggestions',
      contexts: ['editable']
    }, () => chrome.runtime.lastError);
    chrome.contextMenus.create({
      id: 'hints-report-missed',
      title: 'Report: hint should appear here',
      contexts: ['editable']
    }, () => chrome.runtime.lastError);
    chrome.contextMenus.create({
      id: 'encrypt-data',
      title: 'Encrypt or Decrypt a String',
      contexts: ['action']
    }, () => chrome.runtime.lastError);
    chrome.contextMenus.create({
      id: 'lock-secure-synced-storage',
      title: 'Lock Secure Synced Storage',
      contexts: ['action']
    }, () => chrome.runtime.lastError);
    if (/Firefox/.test(navigator.userAgent)) {
      chrome.contextMenus.create({
        id: 'open-options',
        title: 'Open Options Page',
        contexts: ['action']
      }, () => chrome.runtime.lastError);
    }
    else {
      chrome.contextMenus.create({
        id: 'open-keyboards',
        title: 'Keyboard Shortcut Settings',
        contexts: ['action']
      }, () => chrome.runtime.lastError);
    }
  };
  chrome.runtime.onInstalled.addListener(once);
  chrome.runtime.onStartup.addListener(once);
}

// Side panel is per-tab and opt-in: we enable it only after the "Save form"
// context menu sets up its payload. Manifest declares default_path so the API
// is available; this disables the global panel so the icon doesn't surface an
// empty form on tabs the user didn't trigger.
chrome.sidePanel?.setOptions?.({enabled: false}).catch(() => {});
chrome.tabs.onRemoved.addListener(tabId => {
  saveRequests.delete(tabId);
  chrome.storage.session.remove('kp-save-form:' + tabId).catch(() => {});
});

// The manifest is the single source of truth for normal hint injection.
// Declarative content scripts are not added to pages that were already open
// while the extension was updated, so refresh those pages once on update.
{
  const hintScripts = [
    '/data/hints/heuristics.js',
    '/data/hints/form-context.js',
    '/data/hints/ignored-fields.js',
    '/data/hints/layout.js',
    '/data/hints/inject.js'
  ];
  const removeLegacyHintRegistration = () => chrome.scripting.unregisterContentScripts({
    ids: ['kp-hints']
  }).catch(() => {});

  // Older releases registered the same scripts dynamically as well as in the
  // manifest. The registration persists, so clean it up on the first worker
  // start even when an unpacked extension was reloaded manually.
  removeLegacyHintRegistration();
  chrome.runtime.onInstalled.addListener(async ({reason}) => {
    if (reason !== 'update') return;
    await removeLegacyHintRegistration();
    const tabs = await chrome.tabs.query({});
    await Promise.allSettled(tabs
      .filter(tab => tab.id && isScriptableUrl(tab.url))
      .map(tab => chrome.scripting.executeScript({
        target: {tabId: tab.id, allFrames: true},
        files: hintScripts
      })));
  });
}

const onCommand = async (info, tab) => {
  tab = tab || await current();

  if (info.menuItemId === 'save-form') {
    if (!isScriptableUrl(tab.url)) {
      notify(tab, 'Not available on this page', '–', '#888');
      return;
    }
    const target = {tabId: tab.id};
    try {
      await openSaveForm(tab, async () => {
        await chrome.scripting.executeScript({
          target: {...target, allFrames: true},
          files: ['/data/helper.js']
        });
        const r = await chrome.scripting.executeScript({
          target: {...target, allFrames: true},
          func: () => {
            const inputs = document.extendedQuerySelectorAll('input[type=password]');
            const forms = inputs
              .map(p => self.detectForm(p, 'input[type=text],input[type=email]'))
              .filter((f, i, l) => f && l.indexOf(f) === i);
            return forms.map(f => {
              const usernames = [
                ...f.extendedQuerySelectorAll('input[type=text]'),
                ...f.extendedQuerySelectorAll('input[type=email]')
              ].flat().map(e => e.value).filter(s => s);
              const passwords = f.extendedQuerySelectorAll('input[type=password]').map(e => e.value).filter(s => s);
              return {usernames, passwords};
            });
          }
        });
        const pairs = r.map(o => o.result).flat().filter(a => a);
        return {pairs, url: tab.url, favicon: tab.favIconUrl};
      });
    }
    catch (e) {
      console.warn(e);
      notify(tab, e);
    }
  }
  else if (info.menuItemId === 'open-options') {
    chrome.runtime.openOptionsPage();
  }
  else if (info.menuItemId === 'open-keyboards') {
    chrome.tabs.create({
      url: 'chrome://extensions/configureCommands'
    });
  }
  else if (info.menuItemId === 'encrypt-data') {
    if (!isScriptableUrl(tab.url)) {
      notify(tab, 'Not available on this page', '–', '#888');
      return;
    }
    try {
      const target = {
        tabId: tab.id
      };
      await chrome.scripting.insertCSS({
        target,
        files: ['/data/safe/inject.css']
      });
      await chrome.scripting.executeScript({
        target,
        files: ['/data/safe/inject.js']
      });
    }
    catch (e) {
      notify(tab, e);
    }
  }
  else if (info.menuItemId === 'generate-password') {
    try { await copy(await generatePassword(), tab); }
    catch (e) { notify(tab, e); }
  }
  else if (info.menuItemId === 'hints-open') {
    chrome.tabs.sendMessage(tab.id, {
      cmd: 'hints-open'
    }, {
      frameId: info.frameId || 0
    }, () => chrome.runtime.lastError);
  }
  else if (info.menuItemId === 'hints-report-missed') {
    chrome.tabs.sendMessage(tab.id, {
      cmd: 'hints-report-missed'
    }, {
      frameId: info.frameId || 0
    }, () => chrome.runtime.lastError);
  }
  else if (info.menuItemId === 'open-embedded') {
    const target = {
      tabId: tab.id
    };
    try {
      await chrome.scripting.insertCSS({
        target,
        files: ['/data/embedded/inject.css']
      });
      await chrome.scripting.executeScript({
        target,
        files: ['/data/embedded/inject.js']
      });
    }
    catch (e) {
      console.warn(e);
      notify(tab, e);
    }
  }
  else if (info.menuItemId === 'lock-secure-synced-storage') {
    chrome.storage.session.remove('ssdb-exported-key');
  }
};
chrome.contextMenus.onClicked.addListener(onCommand);
chrome.commands.onCommand.addListener((command, tab) => onCommand({
  menuItemId: command
}, tab));

const icon = () => chrome.storage.session.get({
  'ssdb-exported-key': ''
}, prefs => {
  const b = Boolean(prefs['ssdb-exported-key']);

  chrome.action.setIcon({
    path: {
      '16': '/data/icons/' + (b ? 'ssdb/' : '') + '16.png',
      '32': '/data/icons/' + (b ? 'ssdb/' : '') + '32.png',
      '48': '/data/icons/' + (b ? 'ssdb/' : '') + '48.png'
    }
  });
});
chrome.runtime.onStartup.addListener(icon);
chrome.runtime.onInstalled.addListener(icon);

/* in KeePassXC mode check */
chrome.storage.onChanged.addListener(ps => {
  if (ps.engine) {
    hints.reset();

    if (ps.engine.newValue === 'keepassxc') {
      if (typeof chrome.runtime.sendNativeMessage === 'undefined') {
        chrome.runtime.reload();
      }
    }
  }
  if (ps['ssdb-exported-key']) {
    icon();
  }
});

/* FAQs & Feedback */
{
  const {management, runtime: {onInstalled, setUninstallURL, getManifest}, storage, tabs} = chrome;
  if (navigator.webdriver !== true) {
    const {homepage_url: page, name, version} = getManifest();
    onInstalled.addListener(({reason, previousVersion}) => {
      management.getSelf(({installType}) => installType === 'normal' && storage.local.get({
        'faqs': true,
        'last-update': 0
      }, prefs => {
        if (reason === 'install' || (prefs.faqs && reason === 'update')) {
          const doUpdate = (Date.now() - prefs['last-update']) / 1000 / 60 / 60 / 24 > 45;
          if (doUpdate && previousVersion !== version) {
            tabs.query({active: true, lastFocusedWindow: true}, tbs => tabs.create({
              url: page + '?version=' + version + (previousVersion ? '&p=' + previousVersion : '') + '&type=' + reason,
              active: reason === 'install',
              ...(tbs && tbs.length && {index: tbs[0].index + 1})
            }));
            storage.local.set({'last-update': Date.now()});
          }
        }
      }));
    });
    setUninstallURL(page + '?rd=feedback&name=' + encodeURIComponent(name) + '&version=' + version);
  }
}




